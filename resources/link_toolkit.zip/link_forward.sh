#!/bin/bash

#Kill any lingering socat instances and rm the old nohup log
pkill socat
rm nohup.out

#Spin up socat instances and safely background them 
#(e.g. they'll continue running even if you end your session)
#the fork parameter stops the socat instances from terminating if connection is lost.
nohup socat /dev/ttyACM0,raw,echo=0 tcp-listen:27780,reuseaddr,fork &
nohup socat /dev/ttyACM1,raw,echo=0 tcp-listen:27781,reuseaddr,fork &
disown -a
