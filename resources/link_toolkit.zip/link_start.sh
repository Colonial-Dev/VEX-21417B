#!/bin/bash
NC='\e[0m'
YELLOW='\e[1;33m'
BLUE='\e[36m'
GREEN='\e[1;32m'

#Clear old device files if present
rm -f /dev/vex0 > /dev/null 2>&1
rm -f /dev/vex1 > /dev/null 2>&1

#Start and safely background socat receivers
nohup socat PTY,raw,echo=0,link=/dev/vex0 tcp:PI_HOSTNAME.local:27780 > /dev/null 2>&1 &
nohup socat PTY,raw,echo=0,link=/dev/vex1 tcp:PI_HOSTNAME.local:27781 > /dev/null 2>&1 &
disown -a
echo -e "${GREEN}Socat pipes opened.${NC}"

#Wait 5 seconds for the connections to go through
#If the chmod commands are run immediately they can fail and PROS-CLI won't be able
#to open the device files
echo -e "${YELLOW}Waiting 5s to allow TCP link to be established...${NC}"
sleep 5
chmod o+rw /dev/vex0
chmod o+rw /dev/vex1
echo -e "${GREEN}Done - pipes are now read/write accessible!${NC}"
