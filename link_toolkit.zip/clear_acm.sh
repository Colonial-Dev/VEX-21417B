#!/bin/bash

#Reloading the cdc_acm module can fix some issues with an IOCTL error, which sometimes
#arises if the link to the Brain is unplugged.
modprobe --remove-dependencies -f cdc_acm
modprobe cdc_acm

